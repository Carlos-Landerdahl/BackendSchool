import com.hotelaria.config.ConfiguracaoJDBC;
import com.hotelaria.dao.impl.FilialDao;
import com.hotelaria.model.FilialHotel;
import com.hotelaria.service.FilialService;

import java.sql.SQLException;
import java.util.List;

public class Main {
    public static void main(String[] args) throws SQLException {}
}